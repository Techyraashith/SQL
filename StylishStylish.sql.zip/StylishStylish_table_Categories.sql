
-- --------------------------------------------------------

--
-- Table structure for table `Categories`
--
-- Creation: Dec 20, 2024 at 02:20 PM
--

DROP TABLE IF EXISTS `Categories`;
CREATE TABLE IF NOT EXISTS `Categories` (
  `Category_id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(255) DEFAULT NULL,
  `Gender` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `Categories`:
--

--
-- Dumping data for table `Categories`
--

INSERT INTO `Categories` (`Category_id`, `Name`, `Gender`) VALUES
(11, 'Clothing', 'Men'),
(12, 'Clothing', 'Women'),
(13, 'Footwear', 'Men'),
(14, 'Footwear', 'Women'),
(15, 'Accessories', 'Men'),
(16, 'Accessories', 'Women'),
(17, 'Bags', 'Unisex'),
(18, 'Jewelry', 'Women'),
(19, 'Watches', 'Unisex'),
(20, 'Sportswear', 'Unisex');
