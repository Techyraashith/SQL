
-- --------------------------------------------------------

--
-- Table structure for table `Customers`
--
-- Creation: Dec 20, 2024 at 12:15 PM
--

DROP TABLE IF EXISTS `Customers`;
CREATE TABLE IF NOT EXISTS `Customers` (
  `Customer_id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(30) NOT NULL,
  `Phone_no` varchar(10) NOT NULL,
  `Email` varchar(60) NOT NULL,
  `ADDRESS` varchar(100) NOT NULL,
  PRIMARY KEY (`Customer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `Customers`:
--

--
-- Dumping data for table `Customers`
--

INSERT INTO `Customers` (`Customer_id`, `Name`, `Phone_no`, `Email`, `ADDRESS`) VALUES
(1, 'Rahul Sharma', '9876543210', 'rahul.sharma@example.com', '123 MG Road, Mumbai'),
(2, 'Ananya Singh', '9765432101', 'ananya.singh@example.com', '456 Brigade Road, Bangalore'),
(3, 'Arjun Verma', '9988776655', 'arjun.verma@example.com', '789 Park Avenue, Delhi'),
(4, 'Pooja Reddy', '9098765432', 'pooja.reddy@example.com', '101 City Center, Hyderabad'),
(5, 'Ravi Kumar', '9871234560', 'ravi.kumar@example.com', '202 North Street, Chennai'),
(6, 'Sanya Mehta', '9988223344', 'sanya.mehta@example.com', '12 Sector-5, Pune'),
(7, 'Kiran Gupta', '9785623412', 'kiran.gupta@example.com', '76 Mall Road, Jaipur'),
(8, 'Meera Iyer', '9123456789', 'meera.iyer@example.com', '55 Gandhi Street, Kochi'),
(9, 'Aman Khan', '9543217890', 'aman.khan@example.com', '44 Beach Road, Goa'),
(10, 'Sneha Nair', '9654321870', 'sneha.nair@example.com', '33 Racecourse Road, Coimbatore'),
(11, 'Ran Vijay Singh', '8976542321', 'alphamale@gmail.com', '39th alphastreet,Delhi'),
(12, 'Arjun Reddy', '7654328976', 'arjunreddy@gmail.com', '76th alphasteet,Pune');
