
-- --------------------------------------------------------

--
-- Table structure for table `OrderDetails`
--
-- Creation: Dec 21, 2024 at 10:26 AM
-- Last update: Dec 24, 2024 at 12:59 PM
--

DROP TABLE IF EXISTS `OrderDetails`;
CREATE TABLE IF NOT EXISTS `OrderDetails` (
  `OrderDetail_id` int(11) NOT NULL AUTO_INCREMENT,
  `Order_id` int(11) DEFAULT NULL,
  `Product_id` int(11) DEFAULT NULL,
  `Quantity` int(11) DEFAULT NULL,
  `Amount` int(11) DEFAULT NULL,
  PRIMARY KEY (`OrderDetail_id`),
  KEY `Order_id` (`Order_id`),
  KEY `Product_id` (`Product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `OrderDetails`:
--   `Order_id`
--       `Orders` -> `Order_id`
--   `Product_id`
--       `Products` -> `Product_id`
--

--
-- Dumping data for table `OrderDetails`
--

INSERT INTO `OrderDetails` (`OrderDetail_id`, `Order_id`, `Product_id`, `Quantity`, `Amount`) VALUES
(1, 1, 41, 2, 1598),
(2, 1, 43, 1, 2499),
(3, 3, 43, 1, 2499),
(4, 3, 42, 1, 999),
(8, 2, 42, 2, 1998),
(9, 2, 41, 2, 1598),
(10, 2, 44, 1, 1499),
(11, 4, 48, 2, 3998),
(12, 4, 47, 1, 1999),
(13, 9, 49, 1, 3999),
(17, 10, 44, 2, 2998),
(18, 10, 50, 1, 2999),
(19, 10, 48, 3, 8997),
(22, 13, 41, 2, 1598),
(23, 13, 45, 1, 699),
(24, 14, 42, 3, 2997),
(25, 15, 47, 1, 1999),
(26, 15, 50, 1, 2999),
(27, 13, 41, 2, 1598),
(28, 13, 45, 1, 699),
(29, 14, 42, 3, 2997),
(30, 15, 47, 1, 1999),
(31, 15, 50, 1, 2999);
