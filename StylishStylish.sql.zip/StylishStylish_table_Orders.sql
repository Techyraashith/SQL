
-- --------------------------------------------------------

--
-- Table structure for table `Orders`
--
-- Creation: Dec 23, 2024 at 02:35 PM
-- Last update: Dec 24, 2024 at 11:08 AM
--

DROP TABLE IF EXISTS `Orders`;
CREATE TABLE IF NOT EXISTS `Orders` (
  `Order_id` int(11) NOT NULL AUTO_INCREMENT,
  `Customer_id` int(11) NOT NULL,
  `Order_date` date DEFAULT NULL,
  `Delivery_address` varchar(255) NOT NULL,
  `Delivery_date` date DEFAULT NULL,
  `Order_status` varchar(255) DEFAULT NULL,
  `Total_Amount` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Order_id`),
  KEY `Customer_id` (`Customer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `Orders`:
--   `Customer_id`
--       `Customers` -> `Customer_id`
--

--
-- Dumping data for table `Orders`
--

INSERT INTO `Orders` (`Order_id`, `Customer_id`, `Order_date`, `Delivery_address`, `Delivery_date`, `Order_status`, `Total_Amount`) VALUES
(1, 1, '2024-06-01', '123 MG Road, Mumbai', '2024-06-05', 'Placed', '4097'),
(2, 2, '2024-06-02', '456 Brigade Road, Bangalore', '2024-06-06', 'Placed', '5095'),
(3, 3, '2024-06-03', '789 Park Avenue, Delhi', '2024-06-07', 'Placed', '4998'),
(4, 4, '2024-06-04', '101 City Center, Hyderabad', '2024-06-08', 'Placed', '5997'),
(9, 9, '2024-06-09', '44 Beach Road, Goa', '2024-06-13', 'Placed', '3999'),
(10, 10, '2024-06-10', '33 Racecourse Road, Coimbatore', '2024-06-14', 'Placed', '14994'),
(13, 5, '2024-06-01', '202 North Street, Chennai', '2024-06-04', 'Placed', '2297'),
(14, 6, '2024-06-02', '12 Sector-5, Pune', '2024-06-05', 'Placed', '2997'),
(15, 7, '2024-06-01', '76 Mall Road, Jaipur', '2024-06-04', 'Placed', '4998');
