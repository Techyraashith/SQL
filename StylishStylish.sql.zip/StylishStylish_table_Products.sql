
-- --------------------------------------------------------

--
-- Table structure for table `Products`
--
-- Creation: Dec 20, 2024 at 12:15 PM
--

DROP TABLE IF EXISTS `Products`;
CREATE TABLE IF NOT EXISTS `Products` (
  `Product_id` int(11) NOT NULL AUTO_INCREMENT,
  `Product_name` varchar(20) NOT NULL,
  `Product_Price` int(11) NOT NULL,
  `Category_id` int(11) NOT NULL,
  PRIMARY KEY (`Product_id`),
  KEY `Category_id` (`Category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `Products`:
--   `Category_id`
--       `Categories` -> `Category_id`
--

--
-- Dumping data for table `Products`
--

INSERT INTO `Products` (`Product_id`, `Product_name`, `Product_Price`, `Category_id`) VALUES
(41, 'Men T-Shirt', 799, 11),
(42, 'Women Kurti', 999, 12),
(43, 'Men Sneakers', 2499, 13),
(44, 'Women Sandals', 1499, 14),
(45, 'Men Belt', 699, 15),
(46, 'Women Scarf', 499, 16),
(47, 'Leather Backpack', 1999, 17),
(48, 'Gold Earrings', 2999, 18),
(49, 'Digital Watch', 3999, 19),
(50, 'Running Shoes', 2999, 20);
